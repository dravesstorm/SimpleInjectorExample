﻿namespace DI.App.Abstractions
{
    public interface IDbEntity
    {
        int Id { get; }
    }
}